package connectfour;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.Property;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application {

	private Controller controller;

	@Override
	public void start(Stage primaryStage) throws Exception {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
		GridPane rootGridPane = loader.load();

		controller = loader.getController();
		controller.createPlayground();

		MenuBar menuBar = createMenu();
		menuBar.prefWidthProperty().bind(primaryStage.widthProperty());
		Pane pane = (Pane) rootGridPane.getChildren().get(0);
		pane.getChildren().add(menuBar);

		Scene scene = new Scene(rootGridPane);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Connect Four");
		primaryStage.setResizable(false);
		primaryStage.show();
	}

	public MenuBar createMenu() {

		Menu file = new Menu("File");

		MenuItem NewGame = new MenuItem("New Game");
		NewGame.setOnAction(event -> reset());

		MenuItem ResetGame = new MenuItem("Reset Game");
		ResetGame.setOnAction(event -> reset());

		SeparatorMenuItem sp = new SeparatorMenuItem();
		MenuItem quit = new MenuItem("Quit");
		quit.setOnAction(Event -> exit());

		file.getItems().addAll(NewGame, ResetGame, sp, quit);

		Menu help = new Menu("Help");

		MenuItem aboutapp = new MenuItem("About App");
		aboutapp.setOnAction(Event -> {
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("About App");
			alert.setHeaderText("About Connect Four Game");
			alert.setContentText("Connect Four is a two-player connection game in which the players first choose a color and then take turns dropping colored discs from the top into a seven-column, six-row vertically suspended grid. The pieces fall straight down, occupying the next available space within the column. The objective of the game is to be the first to form a horizontal, vertical, or diagonal line of four of one's own discs. Connect Four is a solved game. The first player can always win by playing the right moves");
			alert.show();
		});

		SeparatorMenuItem spp = new SeparatorMenuItem();
		MenuItem aboutMe = new MenuItem("About Developer");
		aboutMe.setOnAction(Event->{
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("About Developer");
			alert.setHeaderText("About Me");
			alert.setContentText("It is ME .Just now I am Begginer but soon i will be Legendary Pro Master");
			alert.show();
		});

		help.getItems().addAll(aboutapp, spp, aboutMe);

		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().addAll(file, help);

		return menuBar;
	}

	private void reset() {
		//TODO
	}

	private void exit() {
		Platform.exit();
		System.exit(0);
	}

	public static void main(String[] args) {

		launch(args);
	}
}
